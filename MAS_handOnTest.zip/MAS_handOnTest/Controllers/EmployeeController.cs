﻿using MAS_handOnTest.Modules.Domain.Entities;
using MAS_handOnTest.Modules.Domain.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;

namespace MAS_handOnTest.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Detail(string param)
        {
            Employee parametro = JsonConvert.DeserializeObject<Employee>(param);
            return View(parametro);
        }
        public JsonResult Get_AllEmployee()
        {
            IEnumerable<Employee> employees = null;
            EmployeeService Obj = new EmployeeService();
            employees=Obj.getAll();
            return Json(employees, JsonRequestBehavior.AllowGet); 
        }
        public JsonResult Get_EmployeeById(int id)
        {
            IEnumerable<Employee> employees = null;
            EmployeeService Obj = new EmployeeService();
            employees = Obj.getEmployeeById(id);
            return Json(employees, JsonRequestBehavior.AllowGet);
        }
    }
}