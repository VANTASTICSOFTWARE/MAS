﻿appEmployeeDet.controller('employeedetailController', function ($scope, $http,  employeedetailInfoService) {
    debugger;
    var id = document.getElementById("id").value;
    //BEGIN - GET EMPLOYEE INFORMATION
   

    angular.element(document).ready(function () {

        if (id != '') {            
            Get_DataEmployee(id);
        }        
    });

    function Get_DataEmployee(code) {

        $http({
            method: "get",
            url: "/Employee/Get_EmployeeById?id=" + Number(code)
        }).then(function (response) {
            $scope.ID = response.data[0].id;
            $scope.NAME=response.data[0].name;
            $scope.CONTRACTTYPENAME = response.data[0].contractTypeName;
            $scope.ROLEID = response.data[0].roleId;
            $scope.ROLENAME = response.data[0].roleName;
            $scope.ROLEDESCRIPTION = response.data[0].roleDescription;
            $scope.HOURLYSALARY = response.data[0].hourlySalary;
            $scope.MONTHLYSALARY = response.data[0].monthlySalary;
            $scope.ANNUALSALARY = response.data[0].annualSalary;

        }, function () {
            alert("Error Occur");
        })

    };
    //END - GET EMPLOYEE INFORMATION

    //BEGIN - Return
    $scope.cancelForm = function () {
        var url = "Index";
        window.location.href = url;
    };
    //END - Return

   
});