﻿
appEmployeeDet.service("employeedetailInfoService", function ($http) {

    this.getInfo = function (id) {
        var req = $http.get('http://localhost:52967/MAS_handOntest/Modules/Get_ParametroById?codPlan=' + code);
        return req;

    };

});
