﻿/// <reference path="F:\Mahesh_New\Articles\Jan15\A1_NG_Boot_MVC5\A1_NG_Boot_MVC5\Scripts/angular.min.js" />
var appEmployeeDet;
(function () {
    appEmployeeDet = angular.module("employeedetailInfoModule", ["ui.bootstrap"]);
    
})();


//appEmployeeDet.config(function ($routeProvider) {
//        $routeProvider
//            .when("/Parametro", {
//                templateUrl: "/Parametro/Index",
//                controller: "ParametroController"
//            })
//            //.when("/newPersonForm", {
//            //    templateUrl: "/MyScripts/pTemplate.html",
//            //    controller: "pController"
//            //})
//            .otherwise({
//                redirectTo: "/home"
//            });
//    });

//    appEmployeeDet.controller("ParametroController",
//        function ($scope, $location, personInfoService) {
//            $scope.showNewPersonForm = function () {
//                $location.path('/Parametro');
//            };
//      });


