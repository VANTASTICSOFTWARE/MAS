﻿var appEmployee = angular.module("AppEmployee", ['ngTouch', 'ui.grid', 'ui.grid.edit', "ui.bootstrap"]);

appEmployee.controller("CtrlEmployee", function ($scope, $http, $uibModal) {
    debugger;
    

    $scope.openEmployeeView = function (param) {
        $scope.ID = param.id;
        $scope.NAME = param.name;
        var url = "Employee/Detail?param=" + JSON.stringify(param);
        redirigirA(url);
    }

    $scope.gridOptions = {
        enableRowSelection: true,
        enableSorting: false,
        enableSelectAll: false,
        selectionRowHeaderWidth: 35,
        rowHeight: 35,
        showGridFooter: true,
        enableColumnMenus: false
    };

    var selectionCellTemplate = '<div class="ngCellText ui-grid-cell-contents">' +
              ' <button class="btn btn-sm btn-warning" ng-click="grid.appScope.openEmployeeView(row.entity)">Open view</button> ' +
              '</div>';

    
    $scope.gridOptions.columnDefs = [
    { name: 'id', displayName: 'Id', width: 90 },
    { name: 'name', displayName: 'Name', width: 230 },
    { name: 'hourlySalary', displayName: 'Hourly Salary', width: 80 },    
    { name: 'monthlySalary', displayName: 'Monthly Salary', width: 80 },
    
{
    name: 'Options', displayName: '', width: 170,
    cellTemplate: selectionCellTemplate
}
    ];

    Get_AllEmployees();


  
    $scope.Search = function () {
        var id = document.getElementById("id").value;
        if (id == '')
        {
            Get_AllEmployees();
        }
        else
        {
            Get_EmployeeById(id);
        }
    };

    function redirigirA(url) {
        var urlBase = "/";
        window.location.href = urlBase + url;
    }

    function Get_EmployeeById(id) {
        $http({
            method: "get",
            url: "/Employee/Get_EmployeeById?id=" + Number(id)
        }).then(function (response) {
            $scope.gridOptions.data = response.data;
        }, function () {
            alert("Error Occur");
        })
    };

    function Get_AllEmployees() {
        $http({
            method: "get",
            url: "/Employee/Get_AllEmployee"
        }).then(function (response) {
            $scope.gridOptions.data = response.data;
        }, function () {
            alert("Error Occur");
        })
    };
});
