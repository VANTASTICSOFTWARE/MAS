﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MAS_handOnTest.Modules.Domain.Entities
{
    public class Employee
    {
        public int id { get; set; }
        public string name { get; set; }
        public string contractTypeName { get; set; }
        public int roleId { get; set; }
        public string roleName { get; set; }
        public string roleDescription { get; set; }
        public decimal hourlySalary { get; set; }
        public decimal monthlySalary { get; set; }
        private decimal _annualSalary;

        public decimal annualSalary
        {
            get {
                decimal valor = 0;
                if (contractTypeName.Equals("MonthlySalaryEmployee"))
                {
                    valor = this.monthlySalary * 12;
                }
                else
                {
                    valor = 120 * this.hourlySalary * 12;
                }
                _annualSalary = valor;
                return _annualSalary; 
            
            }
            set {
                if (contractTypeName.Equals("MonthlySalaryEmployee"))
                {
                    value = this.monthlySalary * 12;
                }
                else
                {
                    value = 120 * this.hourlySalary * 12;
                }

                _annualSalary = value; 
            
            }
        }
        
    }
}