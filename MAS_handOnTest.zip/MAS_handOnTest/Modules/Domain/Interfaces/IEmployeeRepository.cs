﻿using MAS_handOnTest.Modules.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MAS_handOnTest.Modules.Domain.Interfaces
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> getAll();
        IEnumerable<Employee> getEmployeeById(int idEmployee);
    }
}
