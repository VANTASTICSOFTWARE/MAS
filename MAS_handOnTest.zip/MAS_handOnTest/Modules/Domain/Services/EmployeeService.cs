﻿using MAS_handOnTest.Modules.Domain.Entities;
using MAS_handOnTest.Modules.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MAS_handOnTest.Modules.Domain.Services
{
    public class EmployeeService: IEmployeeRepository
    {
        private string routeMasApi = "http://masglobaltestapi.azurewebsites.net/api/employees";

        public IEnumerable<Entities.Employee> getAll()
        {
            IEnumerable<Employee> employees = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(routeMasApi);
                //HTTP GET
                var responseTask = client.GetAsync("employees");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<Employee>>();
                    readTask.Wait();

                    employees = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    employees = Enumerable.Empty<Employee>();
                }
            }
            return employees;
        }

        public IEnumerable<Entities.Employee> getEmployeeById(int idEmployee)
        {
            IEnumerable<Employee> employee = null;
            var result=this.getAll();
            employee= result.Where(i => i.id.Equals(idEmployee)).ToList();
            return employee;
        }
    }
}